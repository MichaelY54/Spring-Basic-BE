package com.mye.project.cookbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CookbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
